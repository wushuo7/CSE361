/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_271()
{
    return 2447754072U;
}

void setval_200(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_201(unsigned x)
{
    return x + 2425393496U;
}

unsigned getval_122()
{
    return 3347663077U;
}

unsigned addval_382(unsigned x)
{
    return x + 2462550344U;
}

void setval_340(unsigned *p)
{
    *p = 2425393240U;
}

unsigned getval_254()
{
    return 2428993864U;
}

void setval_127(unsigned *p)
{
    *p = 2455295778U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_301()
{
    return 3372799627U;
}

unsigned getval_118()
{
    return 2430634312U;
}

unsigned getval_478()
{
    return 3230974345U;
}

unsigned addval_451(unsigned x)
{
    return x + 2425408141U;
}

unsigned addval_112(unsigned x)
{
    return x + 3285617026U;
}

unsigned addval_469(unsigned x)
{
    return x + 3674789505U;
}

void setval_480(unsigned *p)
{
    *p = 2446756229U;
}

unsigned getval_464()
{
    return 3281046153U;
}

unsigned addval_410(unsigned x)
{
    return x + 3674265225U;
}

void setval_124(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_270()
{
    return 3221275017U;
}

unsigned addval_220(unsigned x)
{
    return x + 3286288712U;
}

unsigned addval_412(unsigned x)
{
    return x + 3401697929U;
}

unsigned getval_108()
{
    return 3374367113U;
}

unsigned addval_362(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_302()
{
    return 3399063184U;
}

void setval_419(unsigned *p)
{
    *p = 3269495112U;
}

unsigned addval_408(unsigned x)
{
    return x + 3353381192U;
}

void setval_496(unsigned *p)
{
    *p = 3677935241U;
}

void setval_425(unsigned *p)
{
    *p = 3286272328U;
}

void setval_366(unsigned *p)
{
    *p = 3378561417U;
}

void setval_294(unsigned *p)
{
    *p = 3221801609U;
}

unsigned getval_211()
{
    return 3523794571U;
}

unsigned addval_250(unsigned x)
{
    return x + 2464188744U;
}

unsigned getval_163()
{
    return 3281046152U;
}

unsigned getval_154()
{
    return 3224950411U;
}

unsigned addval_385(unsigned x)
{
    return x + 3523264905U;
}

unsigned getval_427()
{
    return 3677929869U;
}

unsigned getval_475()
{
    return 3251276154U;
}

void setval_229(unsigned *p)
{
    *p = 3525362121U;
}

void setval_383(unsigned *p)
{
    *p = 3525362057U;
}

void setval_238(unsigned *p)
{
    *p = 1069664905U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
